#!/usr/bin/env python
# coding: utf-8

# In[1]:


#load library
import numpy as np


# In[10]:


#create one dimenssion arary with 0 and nan then discard nan and 0
a = np.array([10,30,55,666,np.nan,67,0,1,0,77,np.nan,66,np.nan])
print(a)

b = np.isnan(a)  #create boolean index 
print(b)

c = a[np.isnan(a)] #select all nan values
print(c)

d = a[~np.isnan(a)] #select all non nan/value 
print(d)
print(type(d))

#discard  0
e = a.nonzero() #return index or non-zero
print(e) #return 
print(d[d.nonzero()]) #select all non-zero values 


# In[15]:


#two dimenssion array 
x = np.array([[np.nan,10,90],
              [98,np.nan,np.nan],
              [11,22,4555]])

print(x)

print(np.isnan(x))

print( x[np.isnan(x)])

print( x[~np.isnan(x)])
y = x[~np.isnan(x)]

z = np.array(y).reshape(-1,3)
print(z)


# In[25]:


'''
•	Data Standardization

data:
sub1 sub2 sub3         wt_avg
.5  9  8700 
.9  8  7700
1   4  5500
.6  10 2000 

data:
c1 c2 c3       
.5  .9  1
.9  .8 .7
1   .1  .6
.6  1   0 
'''
#load library or package 
import pandas as pd 
from sklearn import preprocessing 

#create dataframe
df = pd.DataFrame(data={'s1':[.5,.9,1,6],'s2':[9,8,4,10],'s3':[8700,7700,500,2000]})
print(df)

#convert to array or get array from df
d = df.values
#print(d)

#create an object of MinMaxScaler()
mns = preprocessing.MinMaxScaler()

#do the transformation 
scaled_data = mns.fit_transform(d) #convert to % based on every array(series/column) scale (min,max)
#print(scaled_data)

#convert back to dataframe
ndf = pd.DataFrame(scaled_data)
print(ndf)




# In[27]:


#mlxtend 
import numpy as np
from mlxtend.preprocessing import standardize

x_train = np.array([[1,10],[4,7],[3,8]])
x_test = np.array([[1,2],[4,3],[6,3]])


x_trrain_std, params = standardize(x_train,columns=[0,1], return_params=True)
print(x_trrain_std)
print(params)


