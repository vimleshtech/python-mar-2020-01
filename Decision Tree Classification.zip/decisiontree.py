#!/usr/bin/env python
# coding: utf-8

# In[1]:


#import library 
import pandas as pd
from sklearn.tree import DecisionTreeClassifier # Import Decision Tree Classifier
from sklearn.model_selection import train_test_split # Import train_test_split function
from sklearn import metrics #Import scikit-learn metrics module for accuracy calculation


# In[13]:


#load data 
#col_names = ['pregnant', 'glucose', 'bp', 'skin', 'insulin', 'bmi', 'pedigree', 'age', 'label']
# load dataset
#header=None, names=col_names
pima = pd.read_csv(r"C:\Users\Vimlesh.Kumar\Desktop\228_482_bundle_archive\diabetes.csv")

print(pima.shape)
print(pima.head())
print(pima.info())

print(pima.describe())


# In[8]:


#Features selection 

feature_cols = ['Pregnancies', 'Insulin', 'BMI', 'Age','Glucose','BloodPressure']
X = pima[feature_cols] # Features
y = pima.Outcome # Target variable

print(X)
print(y)


# In[12]:


#split data in train and test 
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=1) # 80% training and 20% test

print(X_train.shape)
print(X_test.shape)
print(y_train.shape)
print(y_test.shape)


# In[35]:


#create an object
clf = DecisionTreeClassifier()

# Train Decision Tree Classifer
clf = clf.fit(X_train,y_train)

#Predict the response for test dataset
y_pred = clf.predict(X_test)

#get accuracy 
print("Accuracy:",metrics.accuracy_score(y_test, y_pred))
o = metrics.accuracy_score(y_test, y_pred)
print("Accuracy in % :", (o*100))

#75%


# In[27]:




