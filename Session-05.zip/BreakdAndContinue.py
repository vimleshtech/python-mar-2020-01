#break : stop the loop or terminate the loop 
for i in range(1,10):
    if i% 3 ==0:
        break
    print(i)

#continue : skip the current itereration and resume from next 
for x in range(1,10):
    if x%3 ==0:
        continue
    print(x)
    #logiccal code 
    
    
