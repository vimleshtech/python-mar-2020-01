#crud : create, read, update , delete
data = []

while True: #infinite
    ch = input('press 1 to add 2 for show 3 for update 4 for delete 0 for exit ')

    if ch =='1':
        eid = input('ene eid ')
        name = input('ene eid ')
        salary = input('ene eid ')
        data.append([eid,name,salary])
        print('new row is added ')

    elif ch=='2':
        #print(data)
        for r in data:
            print(r)
    elif ch=='3':
        eid =input('enter eid :')
        for i in range(0,len(data)):
            if data[i][0] == eid:
                newname = input('enter new name :')
                newsalary = input('etner new sal :')
                data[i][1] = newname
                data[i][2] = newsalary                

    elif ch=='4':
        eid =input('enter eid which you want to remove :')
        mrow = []
        for i in range(0,len(data)):
            if data[i][0] == eid:
                mrow.append(data[i])
                break

        if len(mrow)<1 :
            print('given vaulue is not found ')
        else:
            data.remove(mrow[0])
                
            
    elif ch=='0':
            break #exit 
    else:
            print('invalid input, plz renter your choice')



