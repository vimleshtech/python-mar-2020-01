for r in range(1,5): # 1 2 3 4
    for c in range(1,4):
        print(c,end='')
    print()

'''
1
2
3
1
2
3
1
2
3
1
2
3
'''
'''
1
12
123
'''
for i in range(1,4):
    for x in range(1,i+1):  #dependency of nested loop on parent loop value 
        print(x,end='') #print value and don't line 
    print() #new line 


#print in reverse order
'''
123
12
1
'''
for i in range(0,3):
    for x in range(1,4-i):
        print(x,end='')
    print()
    
    










    


            
