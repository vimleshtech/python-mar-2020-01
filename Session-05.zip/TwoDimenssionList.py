#data
d = [11,3,5,66,'fff'] #one dimenssion list

#three rows and three 
data = [[11,233,5],[44,5566,'fff'],[666,777,'fff']]

print(data) #print all

print(data[1]) #print 2nd row

#print all row
for r in data:
    print(r)
    

#print 2nd row and 2 cols
print(data[1][1]) #5566

#read all data one by one
for row in data:  # [] 
    for col in row: # val
        print(col,end='\t')
    print()
    
        

####
x =[] #empty list
for r in range(3):
    row = []
    eid = input('enter eid :')
    name = input('enter name :')
    row.append(eid)
    row.append(name)
    x.append(row)


print(x)

#or
x =[] #empty list
for r in range(3):  
    eid = input('enter eid :')
    name = input('enter name :')   
    x.append([eid,name])









    



    
    
    
        





