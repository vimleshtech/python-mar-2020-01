#set example: operation
a = [111,33,5,77,33,56,111,222,33,5,5,11]

print(a)

#get list of unique
s = set(a) #convert to set

print(s)

s.pop() #remove fist
print(s)

for x in s:
    print(x)
    


s.clear()
print(s) #remove all



