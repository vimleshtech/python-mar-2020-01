from  data_processing import load_data

#import models 

from sklearn.linear_model import LinearRegression

from sklearn.model_selection import cross_val_score
from sklearn.model_selection import cross_val_score
from sklearn.model_selection import StratifiedKFold
from sklearn.metrics import classification_report
from sklearn.metrics import confusion_matrix
from sklearn.metrics import accuracy_score
from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.neighbors import KNeighborsClassifier
from sklearn.discriminant_analysis import LinearDiscriminantAnalysis
from sklearn.naive_bayes import GaussianNB
from sklearn.svm import SVC


data,xv,xt,yv,yt = load_data('aaon.us.txt')
#print(data)
print(xv)


# Algorithms
models = []
#models.append(('a','x'))
#models.append(('b','y'))

o = LinearRegression()
o.fit(xv,yv)
print(o.intercept_)

out = o.score(xv,yv)
print('accurracy  ', (out * 100))  #99% 

#out = o.predict(xt)
#print(out)










'''
models.append(('LR', LogisticRegression(solver='liblinear', multi_class='ovr')))
models.append(('LDA', LinearDiscriminantAnalysis()))
models.append(('KNN', KNeighborsClassifier()))
models.append(('CART', DecisionTreeClassifier()))
models.append(('NB', GaussianNB()))
models.append(('SVM', SVC(gamma='auto')))

results=[]
for name,model in models:
    kfold = StratifiedKFold(n_splits=5, random_state=1, shuffle=True)
    cv_results = cross_val_score(model, xv, yv, cv=kfold, scoring='accuracy')
    results.append(cv_results)
	#names.append(name)
	#print('%s: %f (%f)' % (name, cv_results.mean(), cv_results.std()))

print(results)


print(models)

output.txt/csv
=============
a.us : 99.10 
a.us : 94.23

'''
