import load_data as ld 
from sklearn.model_selection import train_test_split

def cleanData(data):
    res = data.corr()
    print(res)

def splitData(data):
    #dataset = data.values 
    #dataset[:]
    dataset = data[['Open','High','Low','Close']]
    
    newdata = dataset.values
    x = newdata[:,0:3]
    y = newdata[:,3]

    x_train, x_validation, y_train, y_validation = train_test_split(x, y, test_size=0.20, random_state=1)

    return dataset,x_train, x_validation, y_train, y_validation

def getStats(data):
    res = data.describe()
    print(res)


def load_data(fname):
    data = ld.getData(fname)
    dataset,x_train, x_validation, y_train, y_validation = splitData(data)
    return dataset,x_train, x_validation, y_train, y_validation

    #print(data)
    #cleanData(data)
    #res = splitData(data)
    #print(res)
    #getStats(res)


#data = ld.getData("aal.us.txt")
#print(data)


