#load library 
import pandas as pd 

#set folder/directory path 
src_path=r'C:\Users\Vimlesh.Kumar\Documents\Development\python-workspace\4538_7213_bundle_archive\Data\Stocks'
#print(src_path)


#read data 
def getData(fname):
    #dataset = pd.read_csv(src_path+'\\aa.us.txt',sep=',')
    dataset = pd.read_csv(src_path+'\\'+fname,sep=',')

    #print(dataset.shape)
    #print(dataset.head())
    return dataset







