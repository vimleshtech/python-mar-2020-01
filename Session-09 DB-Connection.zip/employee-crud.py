#import the python library/package
import mysql.connector as con

#establish the connection 
c = con.connect(host='localhost',user='root',password='root',database='employee_db')

#exectue the sql statement or command
cur = c.cursor()

def save(eid,name,gender,salary):
    cur.execute("insert into employee(eid,name,gender,salary) values({},'{}','{}',{})".format(eid,name,gender,salary))
    c.commit() #save data to database table
    print('data is saved ')
    

def show():
    cur.execute("select * from employee")
    data = cur.fetchall()
    for row in data:
        print(row)
        

def delete(eid):
    cur.execute("delete from employee where eid={}".format(eid))
    c.commit()
    print('row is deleted')
    

del update(eid,name,salary):
    cur.execute("update employee set name='{}', salary={} where eid={}".format(name,salary,eid))
    c.commit()
    print('data is updated')
    










    





    
    
