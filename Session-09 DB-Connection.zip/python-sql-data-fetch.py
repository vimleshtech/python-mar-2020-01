#import the python library/package
import mysql.connector as con

#establish the connection 
c = con.connect(host='localhost',user='root',password='root',database='hrms')

#exectue the sql statement or command
cur = c.cursor()
cur.execute('select * from products')

#get output of sql statement
data = cur.fetchall()

#show data 
#print(data)
total = 0
for row in data:
 print(row[0],row[1],row[2])
 total+= row[2]
print('total amt is ',total)

 


