import employeecrud as e

e.show()

eid = input('enter eid :')
name = input('enter name :')
gen = input('enter gender :')
sal = input('enter sal :')


e.save(eid,name,gen,sal)
e.show()



