# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.shortcuts import render
from django.http import HttpResponse

# Create your views here.

def index(request):
    return HttpResponse(" <div> <h1> Hi, this is first web app ... </h1> Enter Name <input type='text' /> <input type='button' value='Get Data' /></div>")



