#read json data
import json

#load the data : load is inbuilt function
#load function convert from byte array (str) to other dict
#convert from json to dict is known as deserialization
#deserialization is opposite of seralization

with open('user2-data.json','r') as reader:
    data = json.load(reader)

print(data)
print(type(data))
print(data['id'])
print(data['title'])
print(data.keys())
print(data.values())

      

    




