import json #import json module which is inbuilt

#data dict
data = {
    "userid": 1,
    "id": 1,
    "title": "delectus aut autem",
    "completed": False
  }

print(data)
print(type(data))

#convert data to json : this concept is also known as serializtion
#serializtion  : convert object(dict,list,tuple) to byte stream
jdata = json.dumps(data,indent=4)
print(jdata)
print(type(jdata))


#store json /str to file
with open('user-data.json','w') as writer:
    writer.write(jdata)

print('data is saved in json format')


    
