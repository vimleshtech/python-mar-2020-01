#json : dump vs dumps
#dumps : convert python dict to str (byte code or serialization)
#dump  : write python dict to json file


import json #import json module which is inbuilt

#data dict
data = {
    "userid": 1,
    "id": 1,
    "title": "delectus aut autem",
    "completed": False
  }
#store json /str to file
with open('user2-data.json','w') as writer:
    json.dump(data,writer)
    
    

    
