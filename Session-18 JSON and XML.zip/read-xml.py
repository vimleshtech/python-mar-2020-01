from bs4 import BeautifulSoup

with open(r'C:\Users\vkumar15\AppData\Local\Programs\Python\Python37-32\user-data.xml','r') as reader:
    data = reader.read()

#print(data)

res = BeautifulSoup(data,'xml')
cou = res.find_all('rows')

print(cou)
print(type (cou))
for c in cou:
    print(c)
    

