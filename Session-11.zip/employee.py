class emp:

    def newEmp(self):
        self.eid = int(input('enter eid :'))
        self.name = input('enter name:')

    def getId(self):
        return self.eid

    def show(self):
        print(f'employe data: eid is {self.eid} and name is {self.name}')
        
