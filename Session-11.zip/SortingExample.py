'''
Access class in different file
Store two values on object and access first one
Sorting :
        type of algo
                i. buuble sort
                ii. insertion sort
                iii. quick sort
                iv. merge sort
                v. heap sort
Big O notation
===================
    time and space complexity    
'''
'''
Sorting:
  a=[   111 22 555 66 333 666 733 666 333]
        0    1  2  3    4   5   6   7  8
   a[0]>a[1]:
       [22 111  555 66 333 666 733 666 333]
   a[0]>a[2]

   a[0]>a[3]

   a[0]>a[4]


   a[0]>a[5]

[22 111  555 66 333 666 733 666 333]
 a[1]>a[2]:
 a[1]>a[3]:
       [22 66   555  111 333 666 733 666 333]
       


   a[0]>a[2]

   




       
   
           
       

'''
a=[111,22,555,66,333,666,733,666,333]
for i in range(len(a)):
    for j in range(i+1,len(a)):
        if a[i]>a[j]:
            temp = a[i]
            a[i] = a[j]
            a[j] = temp

print(a)

            
    






