from employee import emp

items = []
for x in range(3):
    o = emp()
    print(o)
    o.newEmp()
    items.append(o)

#sorting
for i in range(len(items)):
    for j in range(i+1,len(items)):
        if items[i].getId()>items[j].getId():
            temp = items[i]
            items[i] = items[j]
            items[j] = temp
    

#show
for obj in items:
    obj.show()
    
