#list
l =[111,4,5,6777]
print(l)
print(l*2)

##convert to array
import numpy as np

x= np.array(l)
print(x)
print(x*2)

#
y = np.arange(10)
print(y)

y = np.arange(1,10,.5)
print(y)

##shape: return dimenssion (no of rows and cols)
print(y.shape) #18 rows 0 cols

#reshape the array
data = np.array(y).reshape(-1,2) #-1 break by row, 2 - two col

print(data)
print(data.shape)

##data type

x = [11,343,5,7,444676]
x = np.array(x)
print(x)
print(type(x))

x = np.array(x,dtype=float)
print(x)
print(type(x))


#
a= np.ones(1000)
print(a)

a= np.zeros(1000)
print(a)

####two dimenssion array calc
a =[1,2,3,4,5,6,7,8,9]

x = np.array(a)
y = x.reshape(-1,3)

x = x*2
z = x.reshape(-1,3)

print(y)
print(z)

print(np.subtract(y,z))
print(np.add(y,z))
print(np.multiply(y,z))
print(np.divide(y,z))
























