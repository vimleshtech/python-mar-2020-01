## decorator


def test(ref):

    print('in test')
    def caller():       
        ref()

    return caller

@test
def a():
    print('in a' )
    return 1

#call to a 
a()

test(a)


