with open(r'C:\Users\vkumar15\Desktop\abcd.txt','w') as f:
    f.write('save some content')
    
print('data is saved')



