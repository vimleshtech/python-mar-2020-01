'''
static: method can be called with or without object
      : obejct ref (self) is not required to receive

Magic method:  is also known as Dunder(double under score)

'''
class test:

    def __init__(self,name): #constructor / magic method 
        
        self.name = name
        
    def __repr__(self):
        return self.name
    def __add__(self,s):
        return self.name+s
    
    
    def add(s,a,b):
        s.c =a+b

    def show(s):
        print(s.c)

    @staticmethod  #@staticmethod : decorator / annotation 
    def tax(amt):
        t = 0
        if amt>1000:
            t =amt*.18
        elif amt>500:
            t=amt*.10
        else:
            t =amt*.12
        print(t)
    

o = test('Object1')
o.add(55,66)
o.show()

o.tax(5566)

#test.tax(55666)

print(o)
print(o+' test')


      

