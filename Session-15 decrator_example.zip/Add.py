f  = open(r'C:\Users\vkumar15\Desktop\TestNG.txt')

#print(f.read())

#print(f.read(40))  #get given number of char

#print(f.tell()) #current position
#print(f.readline())
#print(f.readline())
#print(f.tell()) #get current position

f.read(300)
print(f.tell())
print(f.read(10))

f.close()



