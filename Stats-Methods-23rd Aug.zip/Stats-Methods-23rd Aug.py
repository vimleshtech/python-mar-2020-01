from scipy.stats import chi2_contingency 
  
#df #dataframe
#pd.crosstab(df.attribuate_x,df.attribuate_y, margins_name='Total') #Mean , Count
#
#pd.crosstab(df.attribuate_x,df.attribuate_y, rownames=['gender'], colnames=['country']) #Mean , Count

# sns.heatmap(pd.crosstab(df.attribuate_x,df.attribuate_y, margins_name='Total'), cmap='YlGnBu...', annot=True, cbar=False)


# defining the table  # two dimenssion list 
data = [[190, 9, 201], [3, 142, 232]]
"""
employee
eid name gender  country  salary ...
1        male
2        male 
3        female 
...
...
#crosstabluate 
         India  US  UK
male      190    9  201
female     3     142  232 

"""
print(type(data))
print(data)
print(len(data))


stat, p, dof, expected = chi2_contingency(data) 
  
print(stat)
print(p)
print(dof)
print(expected)

# interpret p-value 
alpha = 0.05
print("p value is " + str(p)[0:4]) 

if float(str(p)[0:4]) <= alpha: 
    print('Dependent (reject H0)') 
else: 
    print('Independent (H0 holds true)') 
    
    

    

