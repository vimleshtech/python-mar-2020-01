'''
math module
'''
import math

#power function
print(math.pow(2,4))

#sqrt function
print(math.sqrt(6))

#value of pi
print(math.pi )


#convert to int 
print(math.ceil(10.222)) #convert to up side / 11
print(math.floor(10.222)) #convert to down side  //10

#factorial function 
print(math.factorial(6))

print(math.sin(90))


'''
statistics module
'''
import statistics as st

###
a = [111,33,5,45,6,6,61,30,666]

print(st.mean(a))
print(st.mode(a)) #value which has highest freq
print(st.median(a)) # 1 2 3 4 5 , median = 3 # 1 2 3 4 5 6 , median = (3+4)/2

print(st.median_high(a))
print(st.median_low(a))
'''
mean  = ?
(111-mean)**2 +  (33-mean)   + ..... / number of values

'''
print(st.variance(a))
print(st.stdev(a)) #sqrt to var

print(st.pstdev(a))











