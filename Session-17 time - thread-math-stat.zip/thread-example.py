'''
Thread module
Thread : is process or task
       : every program is one thread or one task  
'''
import time
import threading
import random


def process1():
    for i in range(1,6):
        #print('series 1: ',i) #print the series
        
        print('data from process 1 :'+str(random.randint(1,1000))+'-')
        time.sleep(1)


def process2():
    for i in range(11,16):
        #print('series 2: ',i) #print the series
        
        print('data from process 2 :'+str(random.randint(1001,2000))+'-')
        time.sleep(1)
        
        

    
#call to function
process1()
process2()

#p1 = threading.Thread(target=process1,name='task1')
#p2 = threading.Thread(target=process2,name='task2')

#p1.start()
#p2.start()







    


