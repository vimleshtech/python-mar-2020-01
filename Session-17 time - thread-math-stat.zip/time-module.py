import time
import datetime

t = time.timezone 
print(t) 


to = time.localtime()
print(to)

print(to.tm_year)
print(to.tm_mon)
print(to.tm_mday)

print(to.tm_hour)
print(to.tm_min)
print(to.tm_sec)

print(f'{to.tm_year}-{to.tm_mon}-{to.tm_mday}')
print(f'{to.tm_year}/{to.tm_mon}/{to.tm_mday}')

#create own date
d = datetime.datetime(2015,11,26)
print(d)
print(type(d))

#get today date

now = datetime.datetime.now()
print(now)
print(now.year)
print(now.strftime("%a")) #get day name
print(now.strftime("%A")) #get day name
print(now.strftime("%w")) #get weekday
print(now.strftime("%d")) #get date
print(now.strftime("%b")) #get month name (abbr)
print(now.strftime("%B")) #get month name (full name)
print(now.strftime("%y"))
print(now.strftime("%Y"))
print(now.strftime("%p"))
print(now.strftime("%m")) 


































