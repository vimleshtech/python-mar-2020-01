class cal:

    def add(self,a,b): #self the receive the ref of object, and a b are variabels
        c =a+b
        print(f'sum of a and b is {c}')


    def mul(s,a,b):
        c =a*b
        print(c)


class tax(cal): #here cal is parent class and tax is child class
    def gst(s,amt):
        t =  amt*.18
        print(t)



    def income_tax(self,salary):
        #....
        t = salary*.10
        print(t)

class dcal(tax):
    def sub(s,a,b):
        return a-b
    
#create an object of child class
o = tax()
o.add(11,455) #call to parent class function
o.mul(11,5)
o.gst(66666)
o.income_tax(6665)







        
