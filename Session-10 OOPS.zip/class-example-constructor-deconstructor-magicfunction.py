class example:

    def add(self,a,b): #self the receive the ref of object, and a b are variabels
        c =a+b
        print(c)

    #constructor method or function
    def __init__(self,name): #this method will invoke automatically        
        #print(f'object is created ,here is object address {self}')
        self.name = name
        self.x=100
        pass
    #deconstructor 
    def __del__(self):
        #print('Object is removed, you can not the same object now')
        pass
    
    #_str__() is magic function     
    def __str__(self):
        return self.name

    #
    def __add__(self,x):
        o = self.x+x.x  #self - o1,  x - o2
        print(o)

#
c1 = example('object-1')
c2 = example('object-2')

c1.add(11,44)
c2.add(11,44)


print(c2) #object-2
print(c1) #object-1

c3 = c1+c2 #+ add 

#delete the object
del c1  #invoke to deconstructor 







