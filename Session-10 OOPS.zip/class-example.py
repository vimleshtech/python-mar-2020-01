#declare class
class employee:
    def newEmployee(self): #self is argument which receive the ref of object

        #print(self)
        self.eid =input('enter eid :')
        self.ename =input('enter name :')
        self.sal = int(input('enter name :'))
        
    def compute(self):
        #print(self)
        hra = self.sal*.40
        other = self.sal
        self.monthly = self.sal+hra+other
        self.ysal = self.monthly*12
        
    def show(self):
        #print(self)
        print(f'eid is {self.eid} name is {self.ename} monthly sal is {self.monthly} and yearly sal is{self.ysal} ')
        

#create object
o1 = employee() #here o is an object of class, and employee is class name
o2 = employee()
print(o1)

o1.newEmployee()
o1.compute()
o1.show()


    
    
