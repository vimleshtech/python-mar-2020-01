
#wap to calculate the tax if amt is greater than 1000
amt = int(input('etner data :'))

tax = 0

if amt>1000:
    tax = amt*.18
    #
    #
    #
elif amt>500:
    tax = amt*.12
elif amt>200:
    tax = amt *.05
else:
    tax = amt*.02
    


total = amt+tax

print('total is ',total)





