
#read value and convert to int 
a = int(input('enter data :'))
b = int(input('enter data :'))

print(type(a))
print(type(b))



c =a+b
print('sum of two values ',c)


print('sum of a and b is c')

#format
print('sum of {} and {} is {}'.format(a,b,c))

print('sum of {1} and {0} is {2}'.format(a,b,c))

#error
#print('sum of {1} and {} is {2}'.format(a,b,c))
