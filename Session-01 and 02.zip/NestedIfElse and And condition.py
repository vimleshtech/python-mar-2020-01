#wap to show greater numebr from three input

a = int(input('enter data for a:'))
b = int(input('enter data for b:'))
c = int(input('enter data for c:'))

#nested if else 

if a>b:
    if a>c:
        print('a is greater ')
    else:
        print('c is greater ')

else:
    if b>c:
        print('b is greater ')
    else:
        print('c is greater ')



#or
if a>b and a>c:
    print('a is greater ')
elif b>a and  b>c:
    print('b is greater ')
else:
    print('c is greate ')




    
