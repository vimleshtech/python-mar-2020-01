
data  =23

print(data+100)
print(data-10)


print(2*3)
print(2**3)
print(23/10)
print(23//10)
print(23%10)


a =1
print(a)
a+=10
print(a)


print('hi')
print('Raman')



print('hi ',end=' ') #don't change line
print('Raman')


print('sum of a and b is c')
