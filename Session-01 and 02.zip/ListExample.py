data = [111,33,5,6,77,333]
print(data) #print all 
print(data[0]) #print first value

print(data[-1]) #print last value


#dynamic list
sales =[] #empty list
print(sales)

'''
val = int(input('enter data :'))
sales.append(val)


val = int(input('enter data :'))
sales.append(val)

val = int(input('enter data :'))
sales.append(val)

val = int(input('enter data :'))
sales.append(val)

val = int(input('enter data :'))
sales.append(val)
'''

i =1
while i<=12:
    val = int(input('enter data :'))

    if val<0 or val>1000:
        print('invalid input or out of range')
    else:
        sales.append(val)
    i =i+1

print(sales)

#read all value one by one
for i in range(len(sales)):  #[0,1,2,3,4,5,....]
    print('data at index {} is {} '.format(i,sales[i]))
    
    
#or
for d in sales:
    
    print(d)
    













