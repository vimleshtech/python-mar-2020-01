
a =55
b =66
c =a/b
#print(c)





