
a , b=11,22

print('a=',a)
print('b=',b)
#want swap b to a and  a to b

####
b,a = a,b

print('a=',a)
print('b=',b)



    
