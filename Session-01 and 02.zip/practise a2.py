name = input('Enter name')
rollno = input('enter roll no')

s1= int( input('enter roll no'))
s2 =int( input('enter roll no'))
s3 =int( input('enter roll no'))
s4 = int(input('enter roll no'))
s5 = int(input('enter roll no'))


total = s1+s2+s3+s4+s5


print ('total marks')

print (total)
print ('average marks')
avg = total/5
print (avg)


            
