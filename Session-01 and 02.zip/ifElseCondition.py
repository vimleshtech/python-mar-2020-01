
#wap to calculate the tax if amt is greater than 1000
amt = int(input('etner data :'))

tax = 0

if amt>1000:
    tax = amt*.18
    #
    #
    #
else:
    tax = amt*.05
    



total = amt+tax

print('total is ',total)





