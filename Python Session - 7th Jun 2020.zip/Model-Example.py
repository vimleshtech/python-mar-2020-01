from pandas import read_csv
from pandas.plotting import scatter_matrix
from matplotlib import pyplot
from sklearn.model_selection import train_test_split




url = r"C:\Users\Vimlesh.Kumar\Downloads\datasets_435_896_sales_data_sample.csv"
#names = ['sepal-length', 'sepal-width', 'petal-length', 'petal-width', 'class']
dataset = read_csv(url,engine='python')

print(dataset)
print(dataset.shape) #(2823, 25)

print(dataset.info())

'''
RangeIndex: 2823 entries, 0 to 2822
Data columns (total 25 columns):
 #   Column            Non-Null Count  Dtype  
---  ------            --------------  -----  
 0   ORDERNUMBER       2823 non-null   int64  
     1   QUANTITYORDERED   2823 non-null   int64  
     2   PRICEEACH         2823 non-null   float64
     3   ORDERLINENUMBER   2823 non-null   int64  
     4   SALES             2823 non-null   float64
 5   ORDERDATE         2823 non-null   object 
 6   STATUS            2823 non-null   object 
     7   QTR_ID            2823 non-null   int64  
     8   MONTH_ID          2823 non-null   int64  
     9   YEAR_ID           2823 non-null   int64  
 10  PRODUCTLINE       2823 non-null   object 
     11  MSRP              2823 non-null   int64  
 12  PRODUCTCODE       2823 non-null   object 
 13  CUSTOMERNAME      2823 non-null   object 
 14  PHONE             2823 non-null   object 
 15  ADDRESSLINE1      2823 non-null   object 
 16  ADDRESSLINE2      302 non-null    object 
 17  CITY              2823 non-null   object 
 18  STATE             1337 non-null   object 
 19  POSTALCODE        2747 non-null   object 
 20  COUNTRY           2823 non-null   object 
 21  TERRITORY         1749 non-null   object 
 22  CONTACTLASTNAME   2823 non-null   object 
 23  CONTACTFIRSTNAME  2823 non-null   object 
 24  DEALSIZE          2823 non-null   object
 '''

##get correlation
co = dataset.corr()
print(co)

#co.to_csv('correlation-data.csv')  



# Split-out validation dataset
array = dataset.values
x = array[:,1:3]  #two dimession array = matrix
y = array[:,4]   #one dimenssion array 

#X_train, X_validation, Y_train, Y_validation = train_test_split(X, y, test_size=0.20, random_state=1)


#print(x)
#print(y)

print(type(x))
print(type(y))

############################# Regression Model ##################################
from sklearn.linear_model import LinearRegression

lm = LinearRegression()
#learn from data using Regression Model 
lm.fit(x,y)
#coeff
#slope
#intercept


out = lm.score(x,y)
print('accurracy of determinatin ',out)

print('intercept ',lm.intercept_)
print('coeff ',lm.coef_)


newd= dataset[['QUANTITYORDERED','PRICEEACH','SALES']]

#newd.plot(kind='box',subplots=True)
newd.plot(kind='line')
pyplot.show()


####
'''
import numpy as np

x= [1,3,4,6,6,3]
x = np.array(x)
y=x*2

pyplot.plot(x,y)
pyplot.show()

'''








