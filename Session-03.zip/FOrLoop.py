#print series from 1 to 10
for x in range(1,11): # from 1 to <11
    print(x)
    

#print in same row/line
for x in range(1,11):
    print(x,end=',')
    

#print in reverse
for i in range(10,0,-1):
    #i =6
    print(i)
    
    

    
    
    
