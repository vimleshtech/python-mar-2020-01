s =input('enter string ')


print(s.count(' '))
print(s.count('\t'))
print(s.count('\n'))

        
