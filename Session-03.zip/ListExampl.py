data = [111,33,5,6,33,6667673]

print(data) #print all
print(data[1]) #print 2nd value

print(data[-1])

print(data[1:3])


print(data[::-1]) #in reverse
print(data)

data.reverse() #change in memory
print(data)


