name =input('enter string data or value ')

print(name.upper())
print(name.lower())
print(name.title())
print(name.capitalize())
print(name.swapcase())


l = list(name)
print(l)



w = name.split(' ') #break by space
print(w)


print(len(name))
name =name.strip()
print(name)
print(len(name))


name =name.lstrip()
name =name.rstrip()

##
print(name.replace('a','xy'))
print(len(name))
print(name.count('a'))


###
print(name[0])
print(name[0:4])
print(name[1:8])
print(name[::-1])



print(chr(67))




##
data = input('enter data :')
if data.isdigit():
    print(int(data),' number value ')
else:
    print('not a number ')



if data.islower():
    print(' in lower case  ')
else:
    print('not in lower')





if data.isupper():
    print('in upper ')
else:
    print('not in upper')





if data.startswith('d'):
    print('start with d')
else:
    print('not start with d ')





if data.endswith('n'):
    print('end with n')
else:
    print('not end with n')





    



    
        







