#

d ={'a':'alpha','d':'delta',1:'hundred',10:[11,33333]}
print(d.keys())
print(d.values())

print(d.items())


#print value by key, find value of given key 
print(d['d'])

#print all
print(d)

#add new key and value
d['new_key']= 'new value'
print(d)

#modify the value
d[10] = 994444

print(d)


#find the key of given value 
for k,v in d.items():
    if v == 'hundred':
        print(k)
    

# wap to convert digit to word
# 123 = one hundered twentry three 
