def getCoinLen(s):

    unique= set(s)
    count= []
    
    for i in range(len(s)):
        sub = s[i:i+len(unique)]
        
        if len(sub) < len(unique): break
        elif len(set(sub)) == len(unique):
            count.append(len(sub))
        else:
            for j in range(i+len(unique), len(s)):
                sub+=s[j]
                if len(set(sub)) == len(unique):
                    count.append(len(sub))
                    break

    return min(count)

m = getCoinLen('aabccde')

#aabcc     3 == 5      
#aabccd
#aabccde   : matched  = 7
#abccd
#abccde     : matched  = 6

print(m)

    

                
                
            


            

        

        

        
        
    



    

