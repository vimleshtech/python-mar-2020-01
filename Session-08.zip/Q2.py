def  example(a,b=[]):
	b.append(a)
	return b

a= example(100)
print(a)			#100
b= example(200,[])
print(b)			# 200
c= example(300,[400])
print(c)			#400 300	
d= example(500)
print(d)			# 500

print(a)			# 100
print(b)			# 200
print(c)			# 400 300
print(d)			# 500
