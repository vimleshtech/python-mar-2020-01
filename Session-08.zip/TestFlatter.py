

out = []
def fallater(e):
        if type(e) in (list,tuple):        
            for d in e:
                fallater(d)
        else:
            out.append(e)

        
            
    

a =[11,22,[444,223,[333,(555,55)],555,333,[44,33]],[33,555],(11,33),4444]
fallater(a)
print(out)

