import re

#search content in given sentence

s = input('enter data :')
o = re.match('(.*) are (.*)',s)

if o:
    print('are is matched ')
else:
    print('are is not matched')


##search
email = input('enter data :')
o = re.search('@gmail.com$',email)
if o:
    print('correct email id ')
else:
    print('incorrect email id ')
    

    



