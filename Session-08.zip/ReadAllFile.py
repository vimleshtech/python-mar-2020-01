import os

src =r'C:\Users\vkumar15\Desktop\src'
f = os.listdir(src)

os.chdir(src)

for x in f:
    if x.endswith('.txt'):
        print('file name is ',x)
        #file = open(src+'\\'+x)
        file = open(x)
        
        print(file.read())
        
    

