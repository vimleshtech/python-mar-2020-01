from django.conf.urls import url
from . import views  # . current folder or directory 


urlpatterns = [
        url('',views.index,name='index')

]