#other type of functions
#5. Argument with default value
def add_num(a,b=0,c=0,d=0): #here b,c,d  contains default value
    m = a+b+c+d
    print(m)

#6. Argument with dynamic count
def mul(*arg): # * : receive multiple arguments
    print(arg) #default type argument is tuple 
    t = 1
    for d in arg:
        t*=d
    print(t)
    
#7. Recussive function
def fact(n):
    if n ==1:
        return n
    else:
        return n*fact(n-1) # 5*4*3*2*1
    
#Anonyms function or lambda expression
tax = lambda a,b: a*.18
'''
def tax(x):
    x =x*.18
    return x
'''
    
#call add_num
add_num(100)
add_num(100,55)
add_num(100,55,66)
add_num(100,666,333,44)
mul(111,3,3,5,6,3,3,6)
mul(111,3,3,5,6,3,3,6,66,33,56,4,6777)

f =fact(5)
print(f)

t = tax(100,555)
print(t)



