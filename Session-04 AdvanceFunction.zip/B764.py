n =1
inc = 0

for i in range(10):
    print(n)
    n =n+4+inc
    inc +=2


    
