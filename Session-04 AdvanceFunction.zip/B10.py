unit = int(input('enter unit :'))

amt = 50

if unit<100:
    amt+= unit*.40
elif unit<300:
        amt+= 40+(unit-100)*.50
else:
     amt+= 140+(unit-300)*.60


print('total amt ',amt)

    
