#1. No argument, no return
def test_function():
    ##to do
    print('this is just an example of functions ')
    print('we are learning function in python ')


#2. No argument, with return 
def getNum():
    a = int(input('enter data :'))
    b = int(input('enter data :'))
    return a,b

#3. Argument with no return     
def tax(amt):
    t = 0
    if amt>10000:
        t =amt*.18
    elif amt>500:
        t =amt*.12
    elif amt>100:
        t =amt*.05
    else:
        t =amt*.02
    print('tax amount is ',t)
        
#4. Argument with return
def mul(a,b):
    c =a*b
    return c

#call or invoke to function
test_function()
test_function()

x,y = getNum()
print(x+y)

x,y = getNum()
print(x-y)

#call with argument

tax(90444)

o = mul(11,444)
print(o)



