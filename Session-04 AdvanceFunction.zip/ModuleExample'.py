#import the module
import mylib

o = mylib.mul(11,44)
print(o)
mylib.tax(5666)


#or
import mylib as m #here m is alias/abb name 
m.tax(5566)


#improt selected function
from mylib import mul

o = mul(55,66)
print(o)

#import all function
from mylib import *
tax(6666)







