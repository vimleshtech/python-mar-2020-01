from tkinter import *

o = Tk()
o.title('Registration Form')
o.geometry('500x400') #width x height 


lfn = Label(o,text='First Name :')
lln = Label(o,text='Last Name :')

lfn.grid(row=2, column=5)
lln.grid(row=4, column=5)

fn=Entry(o)
ln=Entry(o)

fn.grid(row=2, column=6)
ln.grid(row=4, column=6)

status = Checkbutton(o,text='is Active')
status.grid(row=5,column=6)

#image ...
img = PhotoImage(file= r"C:\Users\vkumar15\Desktop\backup\blog-logo.png")
im= img.subsample(2,2)

Label(o,image=im).grid(row=0,column=5)

mainloop()
