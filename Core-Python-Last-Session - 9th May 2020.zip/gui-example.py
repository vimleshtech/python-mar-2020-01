from tkinter import *
from save_data import save
o = Tk()
o.title('Registration Form')
o.geometry('500x400') #widht x height 


#First name 
lfn = Label(text='Enter First Name :')
lfn.pack()

fn=Entry()
fn.pack()

#Last name 
lln = Label(text='Enter Last Name :')
lln.pack()

ln=Entry()
ln.pack()

#Email
lemail = Label(text='Enter Email Id :')
lemail.pack()

email=Entry()
email.pack()

#label to show the message
msg  = Label(text='')
msg.pack()

#create event or function
def frm_clear():
    print('you have clicked on clear button ')
    fn.delete(0,'end')
    ln.delete(0,'end')
    email.delete(0,'end')
    

def frm_save():
    print('you have clicked on save button ')
    fname =  fn.get()
    lname = ln.get()
    emailid = email.get()

    res = save(fname,lname,emailid)
    frm_clear() #clear the form 
    print(f'your name is  {fname} {lname} and email id is {emailid} ')

    #msg.configure(text=f'your name is  {fname} {lname} and email id is {emailid} ')
    msg.configure(text=res)    
    
    
##create button
clear=Button(text='Clear',command=frm_clear)
clear.pack()

submit=Button(text='Save',command=frm_save)
submit.pack()


o.mainloop()

