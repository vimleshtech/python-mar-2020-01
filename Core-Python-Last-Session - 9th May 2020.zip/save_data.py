import mysql.connector as con


c = con.connect(host='localhost',user='root',password='root',database='gui')
cur = c.cursor()


def save(fn,ln,email):
    sql = f"insert into users(fname,lname,email) values('{fn}','{ln}','{email}');"
    
    cur.execute(sql)
    c.commit()
    return "data is saved"


