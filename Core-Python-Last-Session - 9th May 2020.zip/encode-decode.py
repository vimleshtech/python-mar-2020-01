st = input('enter data to convert/encode ')

s = st.encode() #default encode : add b before string 
print(s)


o =s.decode() #default decode : remove the b 
print(o)

#encode with given logic or format
s = st.encode('utf-8')
print(s)

#base64
st='test data'
st.encode(encoding='utf-8',errors='strict')
s = st.encode('base64','strict')
print(s)





