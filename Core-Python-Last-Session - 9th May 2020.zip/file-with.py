#f = open(r'C:\Users\vkumar15\Desktop\node-js\log.txt','w')

#f.write('test code ','\n')
#f.write('test code '+'\n')
    
#f.close()




## or
#with will close the file automatically 
with open(r'C:\Users\vkumar15\Desktop\node-js\log.txt','w') as f:
    
    f.write('\nhi')


    
    
