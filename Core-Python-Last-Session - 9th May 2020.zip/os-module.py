#os (operating system file and folder handler) module
import os

#get current path
cpath  = os.curdir #"."
print(cpath)

#change the path
os.chdir(r'C:\Users\vkumar15\Desktop\node-js')

#get list of files and directory
f= os.listdir()
print(f)







