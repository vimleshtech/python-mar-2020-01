
f = open(r'C:\Users\vkumar15\Desktop\node-js\log.txt','r')


#read all content from file
print(f.read())

#get the file name 
print(f.name)


#read first line
print(f.readline())

#get the current index
print(f.tell())

#reset the file index
f.seek(0,0) #offset (go back and reset the index)
print(f.readline())

#get the current index
print(f.tell())


