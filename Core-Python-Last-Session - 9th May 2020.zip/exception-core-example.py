l = [11,34,5,2,2,5,'ff','ff',4444]

#get the sum of all values

s = 0
for x in l:
    try:
        s+=x
    except:
        pass

print('sum of all values ',s)

    

