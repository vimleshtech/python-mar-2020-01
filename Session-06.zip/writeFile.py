x = open(r'C:\Users\vkumar15\Desktop\newfile.txt','w')  #create new file if not exit, overwrite if exist
#'a' : append 

for r in range(5):
    s = input('enter data :')
    x.write(s+'\n')

x.close()


    
