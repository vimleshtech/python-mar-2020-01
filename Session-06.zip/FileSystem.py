import os
import shutil

#to change the working directory
os.chdir(r'C:\Users\vkumar15\Desktop\temp')

#get list files and folder
files =  os.listdir()

#print(files)

for f in files:
    if f.endswith('.txt' ):    
        print(f)
        #shutil.move(f,r'C:\Users\vkumar15\Desktop')
        shutil.copy(f,r'C:\Users\vkumar15\Desktop')
        

        
    

