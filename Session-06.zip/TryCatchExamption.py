#try catch example

n = int(input('enter number :'))
d = int(input('enter number :'))


#div
try:

    if d<0:
        er =ZeroDivisionError('divior cannot be less than 0')
        raise er #go to except block 
    
    o =n/d #error, go to except 
    print(o)
except ZeroDivisionError as e:
    print(e)
except NameError as e:
    print(e)
except TypeError as e:
    print(e)
except: #handler 
    #pass    #sliently fail
    print('something went wrong, plz try after some time')
finally:
    print('end of block ')
    #block

#add
o =n+d
print(o)



