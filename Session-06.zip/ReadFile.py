
x = open(r'C:\Users\vkumar15\Desktop\AWS.txt','r') # r - read mode

#print(x.read()) #read all content from file

#print(x.readline()) #read one line at a time 
#print(x.readline())

data = x.readlines() #read all content from file and convert to list
x.close() #save the file and clear the memory 

#every line of become one element of list
print(data)

wc = 0

for r in data:
    print(r)
    s = r.split()
    wc+= len(s)
    
#row count
print(len(data))
print('word count ',wc)






