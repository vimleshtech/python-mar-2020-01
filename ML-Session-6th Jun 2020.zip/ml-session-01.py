# load the library
from pandas import read_csv 
from matplotlib import pyplot
from sklearn.model_selection import train_test_split


#file /data source
url=r"C:\Users\Vimlesh.Kumar\Documents\Development\python-workspace\iris.csv"
#column name , because file not contain header 
column = ['sepal_length',	'sepal_width',	'petal_length'	,'petal_width',	'species']

#read file 
dataset = read_csv(url,names=column)

#show top 5 rows
print(dataset.head())

#show header or column 
print(dataset.columns)


#Summarize the Dataset
print(dataset.shape)  #150 rows, 5 cols

####
print(dataset.head(10)) #show top 10 rows
print(dataset.tail(10)) #show buttom 10 rows

####show stats 
print(dataset.info()) #show datatype and column is nullable or not 

print(dataset.describe())
'''
       sepal_length  sepal_width  petal_length  petal_width
count    150.000000   150.000000    150.000000   150.000000
mean       5.843333     3.054000      3.758667     1.198667
std        0.828066     0.433594      1.764420     0.763161   #std is sqrt to variance 
min        4.300000     2.000000      1.000000     0.100000
25%        5.100000     2.800000      1.600000     0.300000
50%        5.800000     3.000000      4.350000     1.300000
75%        6.400000     3.300000      5.100000     1.800000
max        7.900000     4.400000      6.900000     2.500000
'''

#group by  : data distribuation 
print(dataset.groupby('species').size()) #show category wise row count

'''
Iris-setosa        50
Iris-versicolor    50
Iris-virginica     50
'''


#Data Visualization :: matplolib 
#dataset.plot(kind='bar')
#dataset.plot(kind='line')

#box plot 
dataset.plot(kind='box', subplots=True, layout=(2,2), sharex=False, sharey=False)
pyplot.show()



#Create a Validation Dataset : break data in  train and test then x(input),y (output)
#ratio of tain and test  : 80:20 , 79:30, 60:40
data = dataset.values #convert dataframe to ndarray 

x =  data[:,0:4]    #get all rows and 0 to 3 cols  (numeric  columns)
y = data[:,4]  #get all rows and 4th col  (alpha numeric)

X_train, X_validation, Y_train, Y_validation = train_test_split(x, y, test_size=.20, random_state=1)#here 1 is incrementer


print(X_train)
print(X_validation)

print(Y_train)
print(X_validation)
















