#how to import data from file to dataframe
import pandas as pd

car = pd.read_csv(r'C:\Users\vkumar15\Documents\Training\Training\Excel VBA\Excel\Car_dataset.csv')
print(car)

print(car.columns)

#save to file
ndf = car[['model', 'mpg', 'cyl', 'disp']]
print(ndf)

#ndf.to_csv(r'C:\Users\vkumar15\Desktop\Data\newfile.csv')
ndf.to_csv(r'C:\Users\vkumar15\Desktop\Data\newfile.csv',index=False)
print('data is saved ')




