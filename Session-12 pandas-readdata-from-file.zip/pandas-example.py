import pandas as pd
#create empty dataframe

df = pd.DataFrame()
print(df) #index, columns


#create dataframe from dict
data ={
    'eid':[1,2,3,4,5,6,7,8,9,10],
    'ename':['Raman','Nitin','Rahul','monika','Nitisha','Divya','Kshitiz','Mohit','Chahat','Gaurav'],
    'gender':['male','male','male','Female','female','female','male','male','female','male'],
    'salary':[41000,29000,83000,94000,51000,66000,71000,82000,59000,81500]}

emp = pd.DataFrame(data)
print(emp) #print dataframe

print(emp.index) #print index(row name)
print(emp.columns) #print col name

#rename the columns
emp.columns = ['emp_code','emp_name','gender','basic_sal']
print(emp)

#rename row index/name
emp.index=['Row1','Row2','Row3','Row4','Row5','Row6','Row7','Row8','Row9','Row10']
print(emp)

#head : print top 5 rows
print(emp.head())
#head : print top given number of rows
print(emp.head(2))  # n=2

#tail: print rows from buttom
print(emp.tail()) #5 rows from buttom
print(emp.tail(3)) #3 rows from buttom

#print select column
print(emp['emp_name'])
print(emp[['emp_name','emp_code','basic_sal']])

#filter rows : print select rows
np = emp[emp['basic_sal']>70000]
print(np)

np = emp[emp['gender']=='female']
print(np)

np = emp[emp['gender']=='female']
np = np[np['basic_sal']>60000]
print(np)

##show column description
print(emp.info()) #show list of column, vaue clount, nullable, datatype
#object: string

##show the stats for all numeric column
''''
count
mean
sd(standard deviaion): sqrt of var 
min
25%
50%
75%
max
'''
print(emp.describe())

#sort the data by given column
#highest to lowest salary 
print(emp.sort_values('basic_sal',ascending=False)) 

#in in asc
print(emp.sort_values('basic_sal',ascending=True))


#by name (string) asc
print(emp.sort_values('emp_name',ascending=True))

#data distribuation / group by
print(emp.groupby('gender').count())
print(emp.groupby('gender').count()['emp_name'])

print(emp.groupby('gender').max()['basic_sal'])
print(emp.groupby('gender').min()['basic_sal'])
print(emp.groupby('gender').sum()['basic_sal'])


#####add the coumn in existing dataframe
hra = [44,666,444,6666,7777,3333,666,888,333,667]
emp['hra_sal']= hra
print(emp)

#drop column or row
emp = emp.drop('hra_sal',axis=1) # axis=1 : by column 
print(emp)

emp = emp.drop('Row4') #remove by row 
print(emp)
            































































